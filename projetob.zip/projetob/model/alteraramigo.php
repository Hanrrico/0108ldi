<?php 
    include_once "../factory/conexao.php";
    
    $nome = $_POST["cxnome"];
    $email = $_POST["cxemail"];
    $datanasc = $_POST["cxdatanasc"];
    $tel = $_POST["cxtel"];
    $cod =  $_POST["cxcodigo"];


    $alterar = "
        UPDATE tbamigos SET

        nome = '$nome',
        email = '$email',
        datanasc = '$datanasc',
        tel = '$tel' 
        where
        cod = '$cod'
    ";

    $executar = mysqli_query($conn,$alterar);
    if ($executar){
            echo "Dados Alterados com sucesso!";
    }
    else{
            echo "Erro ao alterar os dados!";
    }
?>

<a href="/projetob/view/telacadamigo.php?action=buscar">Voltar</a> 

