<?php
    include_once "../factory/conexao.php";
    $id = $_GET["id"];
    $excluir = "delete from tbusuario where 
    cod='$id' ";
    $executar = mysqli_query($conn,$excluir);
    if($executar){
         echo "Usuário excluido com sucesso!";
         echo "<br/>";
         echo "<a href='/projetob/view/telacaduser.php?action=buscar'>
         Voltar</a>";
    }
    else
    {
         echo "Erro de dados ao excluir o usuário";
    }
?>