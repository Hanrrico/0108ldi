<?php 
    include_once "../factory/conexao.php";
    
    $contato = $_POST["cxcontato"];
    $tel = $_POST["cxtel"];
    $empresa = $_POST["cxempresa"];
    $email = $_POST["cxemail"];
    $cod =  $_POST["cxcodigo"];


    $alterar = "
        UPDATE tbcomercio SET 
        contato = '$contato',
        tel = '$tel',
        empresa = '$empresa',
        email = '$email'
        where
        cod = '$cod'
    ";

    $executar = mysqli_query($conn,$alterar);
    if ($executar){
            echo "Dados Alterados com sucesso!";
    }
    else{
            echo "Erro ao alterar os dados!";
    }
?>

<a href="/projetob/view/telacadcomercio.php?action=buscar">Voltar</a> 

