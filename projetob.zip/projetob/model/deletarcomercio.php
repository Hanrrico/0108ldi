<?php
    include_once "../factory/conexao.php";
    $id = $_GET["id"];
    $excluir = "delete from tbcomercio where 
    cod='$id' ";
    $executar = mysqli_query($conn,$excluir);
    if($executar){
         echo "Comercio excluido com sucesso!";
         echo "<br/>";
         echo "<a href='/projetob/view/telacadcomercio.php?action=buscar'>
         Voltar</a>";
    }
    else
    {
         echo "Erro de dados ao excluir o comércio";
    }
?>