<?php
    include_once "../factory/conexao.php";
    $id = $_GET["id"];
    $excluir = "delete from tbamigos where 
    cod='$id' ";
    $executar = mysqli_query($conn,$excluir);
    if($executar){
         echo "Amigo excluido com sucesso!";
         echo "<br/>";
         echo "<a href='/projetob/view/telacadamigo.php?action=buscar'>
         Voltar</a>";
    }
    else
    {
         echo "Erro de dados ao excluir o amigo";
    }
?>
